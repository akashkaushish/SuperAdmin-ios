//
//  MusicViewController.h
//  SuperAdmin
//
//  Created by Gauri Shankar on 01/11/16.
//  Copyright © 2016 gauri shankar. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface MusicViewController : UIViewController

@property (strong, nonatomic) NSString *topTitle;

@end
