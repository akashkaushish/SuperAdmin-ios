//
//  MainViewController.h
//  SuperAdmin
//
//  Created by Gauri Shankar on 03/11/16.
//  Copyright © 2016 gauri shankar. All rights reserved.
//

#import <UIKit/UIKit.h>
//For UMG users

@interface MainViewController : UIViewController

@end
