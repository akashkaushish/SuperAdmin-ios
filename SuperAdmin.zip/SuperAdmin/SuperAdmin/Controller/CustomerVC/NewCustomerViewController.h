//
//  NewCustomerViewController.h
//  SuperAdmin
//
//  Created by Gauri Shankar on 08/11/16.
//  Copyright © 2016 gauri shankar. All rights reserved.
//

#import <UIKit/UIKit.h>
//For MCB users customer user

@interface NewCustomerViewController : UIViewController

@end
