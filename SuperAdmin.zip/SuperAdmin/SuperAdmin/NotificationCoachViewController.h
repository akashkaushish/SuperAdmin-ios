//
//  NotificationCoachViewController.h
//  NotificationPOC
//
//  Created by Gauri Shankar on 21/04/16.
//  Copyright © 2016 RnF-12. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface NotificationCoachViewController : UIViewController
@property (strong, nonatomic) NSString *topTitle;

@end
