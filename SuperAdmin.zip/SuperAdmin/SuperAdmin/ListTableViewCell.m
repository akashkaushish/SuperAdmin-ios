//
//  ListTableViewCell.m
//  NotificationPOC
//
//  Created by Gauri Shankar on 15/03/16.
//  Copyright © 2016 RnF-12. All rights reserved.
//

#import "ListTableViewCell.h"

@implementation ListTableViewCell

- (void)awakeFromNib {
    // Initialization code
}

- (void)setSelected:(BOOL)selected animated:(BOOL)animated {
    [super setSelected:selected animated:animated];

    // Configure the view for the selected state
}

@end
