//
//  MainCoachViewController.h
//  NotificationPOC
//
//  Created by Gauri Shankar on 01/04/16.
//  Copyright © 2016 RnF-12. All rights reserved.
//

#import <UIKit/UIKit.h>
//for mcb coach user

@interface MainCoachViewController : UIViewController

@end
